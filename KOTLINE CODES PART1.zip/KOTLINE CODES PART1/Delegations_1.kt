interface Task{
    fun Create()
}

interface Execute{
    fun Execute()
}
class TaskManager(val Creator:Task,val Executer:Execute):Task,Execute{
override fun Create(){
Creator.Create()
}

override fun Execute(){
Executer.Execute()
}
}
fun main(){
    val a1=TaskManager;
}