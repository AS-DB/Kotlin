class FirstProgram{
companion object{
    @JvmStatic
    fun main(args : Array<String>){
        println("Hello")
    }
}}
